/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included  with this distribution in *
 * the LICENSE file.                                                         *
 *****************************************************************************/

package org.apache.james.james.servlet;

import java.io.*;
import java.util.*;
import org.apache.arch.*;
import org.apache.james.*;
import org.apache.avalon.blocks.*;
import org.apache.mail.*;
import org.apache.james.james.*;
import javax.mail.Transport;
import javax.mail.Session;
import javax.mail.URLName;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.*;

/**
 * Receive  a Mail from JamesSpoolManager and takes care of delivery 
 * the message to local inboxs.
 *
 * @author  Federico Barbieri <scoobie@pop.systemy.it>
 */
public class Maillist extends GenericMailServlet implements TimeServer.Bell {

    private Store.ObjectRepository subscribed;
    private Store.ObjectRepository subscribing;
	private TimeServer timeServer;
	private MailServer server;
    private String listName;
    private String ON;
    private String OFF;
    private String ADMIN;
    private String admin;
    private String admpass;
    private String postmaster;
    private static final String ERROR_SUBJECT = "Error Message";
    private long subscribingTimeout;

    public void init() 
    throws Exception {
        ComponentManager comp = getComponentManager();
        Context context = getContext();
        Store store = (Store) comp.getComponent(Interfaces.STORE);
		timeServer = (TimeServer) comp.getComponent(Interfaces.TIME_SERVER);
		server = (MailServer) comp.getComponent(Interfaces.MAIL_SERVER);
		postmaster = (String) context.get(Constants.POSTMASTER);
        listName = getConfiguration("name").getValue();
        admin = getConfiguration("admin").getValue();
        admpass = getConfiguration("admpass").getValue();
        subscribingTimeout = getConfiguration("subscribingTimeout", "86400000").getValueAsLong(); // default set to 24*60*60*1000
        String subscribedPath = getConfiguration("subscribedPath", "file://../mail/lists/" + listName + "/").getValue();
        subscribed = (Store.ObjectRepository) store.getPrivateRepository(subscribedPath, Store.OBJECT, Store.ASYNCHRONOUS);
        subscribing = (Store.ObjectRepository) store.getPrivateRepository(subscribedPath + "temp/", Store.OBJECT, Store.ASYNCHRONOUS);
        ON = getConfiguration("ext.on", "-on").getValue();
        OFF = getConfiguration("ext.off", "-off").getValue();
        ADMIN = getConfiguration("ext.admin", "-admin").getValue();
    }
    
    public Mail service(Mail mc) {
        Vector recipients = mc.getRecipients();
        String sender = mc.getSender();
        if (recipients.size() > 1) {
                // reply with error: cannot handle more than one recipient at a time
            log("more than one recipient found. Cannot handle message");
            reply(mc, "ERROR PROCESSING MESSAGE! " +
                "Cannot send this message to more than one '" + listName + "' recipient");
            return null;
        }
        String target = getUser((String) recipients.elementAt(0));
        String subject = "";
        try {
            subject = mc.getMessage().getSubject();
        } catch (MessagingException me) {
        }
        
        if (target.equalsIgnoreCase(listName)) {
            recipients.clear();
            if (!subscribed.containsKey(sender)) {
                reply(mc, "You are not subscribed to this list. Please subscribe first mailing " + listName + ON);
                return null;
            } else {
                for (Enumeration e = subscribed.list(); e.hasMoreElements(); ) {
                    recipients.addElement(e.nextElement());
                }
                mc.setRecipients(recipients);
                return mc;
            }
        } else if (target.equalsIgnoreCase(listName + ON)) {
            if (subscribed.containsKey(sender)) {
            } else if (subscribing.containsKey(sender)) {
                String secretKey = (String) subscribing.get(sender);
                if (subject.indexOf(secretKey) != -1) {
                    subscribed.store(sender, "Subscribed");
                    subscribing.remove(sender);
            		timeServer.removeAlarm(sender);
                    reply(mc, "Welcome to " + listName);
                } else {
                    reply(mc, "The key you send do not match the one we send to you."); 
                }
            } else {
                String secretKey = "" + sender.hashCode() + System.currentTimeMillis();
                subscribing.store(sender, secretKey);
        		timeServer.setAlarm(sender, this, subscribingTimeout);
        		reply(mc, "reply to this message placing this key as subject: " + secretKey);
            }
            return null;
        } else if (target.equalsIgnoreCase(listName + OFF)) {
            if (subscribed.containsKey(sender)) {
                subscribed.remove(sender);
            }
            return null;
        } else if (target.equalsIgnoreCase(listName + ADMIN)) {
            if (!sender.equalsIgnoreCase(admin)) {
                return null;
            }
            if (!subject.equals(admpass)) {
                return null;
            }
            // read instructions from the mailbody and execute them
        }
        return null;
    }
    
	public void wake(String name, String memo) {
		subscribing.remove(name);
log("removing subscriber");
	}

    public String getServletInfo() {
        return "Mail List Servlet";
    }
    
    private String getUser(String recipient) {
        return recipient.substring(0, recipient.indexOf("@"));
    }

    private void reply(Mail mc, String content) {
        try {
    		MimeMessage reply = (MimeMessage) (mc.getMessage()).reply(false);
    		reply.setFrom(new InternetAddress(listName));
    		InternetAddress[] add = {new InternetAddress(mc.getSender())};
    		reply.setRecipients(Message.RecipientType.TO, add);
    		reply.setSubject("Re: " + mc.getMessage().getSubject());
            MimeMultipart body = new MimeMultipart();
            MimeBodyPart msg = new MimeBodyPart();
            msg.setText(content);
            body.addBodyPart(msg);
            reply.setContent(body);
            Vector recipient = new Vector();
            recipient.addElement(mc.getSender());
            server.sendMail(listName, recipient, reply);
    	} catch (Exception e) {
    	}
	}
}
    
